package com.myapp.services.impl;

import com.myapp.dao.employeeDAO;
import com.myapp.dao.oracle.EmployeeOracleDao;
import com.myapp.entity.employees;
import com.myapp.services.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	employeeDAO empDao;
	public EmployeeServiceImpl() {
		empDao=new EmployeeOracleDao();
	}
	@Override
	public employees getEmployee(int employeeId) throws Exception {
		// TODO Auto-generated method stub
		return empDao.getEmployeeById(employeeId);
	}

	@Override
	public employees getEmployeeAllDetails(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addEmployee(employees e) throws Exception {
		// TODO Auto-generated method stub
		empDao.addEmployee(e);

	}

	@Override
	public void updateEmployee(employees e) throws Exception {
		// TODO Auto-generated method stub
		empDao.updateEmployee(e);

	}

	@Override
	public void deleteEmployee(int employeeId) throws Exception {
		// TODO Auto-generated method stub
		empDao.deleteEmployee(employeeId);

	}

}
