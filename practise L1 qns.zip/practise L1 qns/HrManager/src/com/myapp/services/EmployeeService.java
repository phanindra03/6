package com.myapp.services;

import com.myapp.entity.employees;

public interface EmployeeService {
	employees getEmployee(int employeeId) throws Exception;

	employees getEmployeeAllDetails(int employeeId);

	void addEmployee(employees e) throws Exception;

	void updateEmployee(employees e) throws Exception;

	void deleteEmployee(int employeeId) throws Exception;

}
