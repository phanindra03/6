package com.myapp.datasource;

import java.sql.Connection;

public class DataSource {
	private static ConnectionPool pool;
	static{
		try{
			
			pool=ConnectionPool.getConnectionPool("C:\\Users\\bmarni\\workspace\\HrManager\\src\\db.properties");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static Connection getConnection() throws Exception {
		return pool.getConnection();
	}
}
