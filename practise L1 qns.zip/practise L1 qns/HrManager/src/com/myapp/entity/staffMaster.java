package com.myapp.entity;

public class staffMaster {
	private int staffCode;
	private String staffName;
	private int designCode;
	private int deptCode;
	private String staffDob;
	private String hireDate;
	private int mgrCode;
	private int staffSal;
	private String staffAddress;
	public int getStaffCode() {
		return staffCode;
	}
	public void setStaffCode(int staffCode) {
		this.staffCode = staffCode;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public int getDesignCode() {
		return designCode;
	}
	public void setDesignCode(int designCode) {
		this.designCode = designCode;
	}
	public int getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(int deptCode) {
		this.deptCode = deptCode;
	}
	public String getStaffDob() {
		return staffDob;
	}
	public void setStaffDob(String staffDob) {
		this.staffDob = staffDob;
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	public int getMgrCode() {
		return mgrCode;
	}
	public void setMgrCode(int mgrCode) {
		this.mgrCode = mgrCode;
	}
	public int getStaffSal() {
		return staffSal;
	}
	public void setStaffSal(int staffSal) {
		this.staffSal = staffSal;
	}
	public String getStaffAddress() {
		return staffAddress;
	}
	public void setStaffAddress(String staffAddress) {
		this.staffAddress = staffAddress;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + deptCode;
		result = prime * result + designCode;
		result = prime * result
				+ ((hireDate == null) ? 0 : hireDate.hashCode());
		result = prime * result + mgrCode;
		result = prime * result
				+ ((staffAddress == null) ? 0 : staffAddress.hashCode());
		result = prime * result + staffCode;
		result = prime * result
				+ ((staffDob == null) ? 0 : staffDob.hashCode());
		result = prime * result
				+ ((staffName == null) ? 0 : staffName.hashCode());
		result = prime * result + staffSal;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		staffMaster other = (staffMaster) obj;
		if (deptCode != other.deptCode)
			return false;
		if (designCode != other.designCode)
			return false;
		if (hireDate == null) {
			if (other.hireDate != null)
				return false;
		} else if (!hireDate.equals(other.hireDate))
			return false;
		if (mgrCode != other.mgrCode)
			return false;
		if (staffAddress == null) {
			if (other.staffAddress != null)
				return false;
		} else if (!staffAddress.equals(other.staffAddress))
			return false;
		if (staffCode != other.staffCode)
			return false;
		if (staffDob == null) {
			if (other.staffDob != null)
				return false;
		} else if (!staffDob.equals(other.staffDob))
			return false;
		if (staffName == null) {
			if (other.staffName != null)
				return false;
		} else if (!staffName.equals(other.staffName))
			return false;
		if (staffSal != other.staffSal)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "staffMaster [staffCode=" + staffCode + ", staffName="
				+ staffName + ", designCode=" + designCode + ", deptCode="
				+ deptCode + ", staffDob=" + staffDob + ", hireDate="
				+ hireDate + ", mgrCode=" + mgrCode + ", staffSal=" + staffSal
				+ ", staffAddress=" + staffAddress + "]";
	}
	public staffMaster(int staffCode, String staffName, int designCode,
			int deptCode, String staffDob, String hireDate, int mgrCode,
			int staffSal, String staffAddress) {
		super();
		this.staffCode = staffCode;
		this.staffName = staffName;
		this.designCode = designCode;
		this.deptCode = deptCode;
		this.staffDob = staffDob;
		this.hireDate = hireDate;
		this.mgrCode = mgrCode;
		this.staffSal = staffSal;
		this.staffAddress = staffAddress;
	}
	
	public staffMaster() {
		// TODO Auto-generated constructor stub
	}

}
