package com.myapp.dao;

import java.util.List;

import com.myapp.entity.departments;

public interface departmentsDAO {
	List<departments> getAllDepartments() throws Exception;
	departments getDepartmentById(int departmentId) throws Exception;
	
	List<departments> getDepartmentsByLocationId(int locationId) throws Exception;
	
	departments getDepartmentByManagerId(int managerId) throws Exception;
	
	void addDepartment(departments d) throws Exception;
	void updateDepartment(departments d) throws Exception;
	void deleteDepartmentById(int departmentId) throws Exception;
}
