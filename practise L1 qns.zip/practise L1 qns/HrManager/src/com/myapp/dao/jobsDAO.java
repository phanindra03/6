package com.myapp.dao;

import com.myapp.entity.jobs;

public interface jobsDAO {
	jobs getJobTitles();
	
	jobs getJobTitleByJobId(String jobId);
	
	jobs getMinSalaryByJobTitle(String jobTitle);
	
	jobs getMaxSalaryByJobTitle(String jobTitle);
	
	jobs getMinSalaryByJobId(String jobId);
	
	jobs getMaxSalaryByJobId(String jobId);
	
	jobs getJobIdByJobTitle(String jobTitle);
	
	void addJobs(jobs j);
	void updateJobs(jobs j);
	void deleteJobs(jobs j);
	void deleteJobs(int jobId);
	
	
	
	

}
