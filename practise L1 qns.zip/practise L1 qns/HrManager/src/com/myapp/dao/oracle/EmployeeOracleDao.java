package com.myapp.dao.oracle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.myapp.dao.employeeDAO;
import com.myapp.entity.employees;

public class EmployeeOracleDao implements employeeDAO {
	Logger Log=Logger.getLogger(EmployeeOracleDao.class.getName());
	
	
	
	
	private Connection getConnection() {
		Connection conn = null;
		FileInputStream fis = null;
		try {
			FileInputStream fis1=new FileInputStream("C:\\Users\\bmarni\\workspace\\HrManager\\src\\log.properties");
			fis = new FileInputStream(
					"C:\\Users\\bmarni\\workspace\\HrManager\\src\\db.properties");
			Properties prop = new Properties();
			Properties prop1 = new Properties();
			prop.load(fis);
			prop1.load(fis1);
			PropertyConfigurator.configure(prop1);
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String username = prop.getProperty("user");
			String password = prop.getProperty("password");
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
			Log.info("Connection Established...");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Class Not Found......");
			
		} catch (FileNotFoundException e) {
			System.out.println("Properties File Not Found.....");
		} catch (SQLException e) {
			System.out.println("Connection Establishment Failed......");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}
		return conn;
	}

	@Override
	public List<employees> getAllEmployees() throws Exception {
		// TODO Auto-generated method stub
		ArrayList<employees> empList = new ArrayList<employees>();
		try {
			Connection conn = getConnection();
			Statement stat = conn.createStatement();
			String q = "SELECT * FROM employees";
			Log.info(q);
			ResultSet rs = stat.executeQuery(q);
			while (rs.next()) {
				employees e = new employees(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getDouble(9), rs.getInt(10), rs.getInt(11));
				empList.add(e);
				Log.info("Data Retrived..");
			}
		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException e) {
			System.out.println("Error in Sql Execution.....");
			Log.info("Error In Sql....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}
		return empList;
	}

	@Override
	public List<employees> getEmployeesByDepartment(int departmentId)
			throws Exception {
		// TODO Auto-generated method stub
		ArrayList<employees> empList = new ArrayList<employees>();
		try {
			Connection conn = getConnection();
			String q = "SELECT * FROM employees where department_id=?";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setInt(1, departmentId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				employees e = new employees(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getDouble(9), rs.getInt(10), rs.getInt(11));
				empList.add(e);
			}
		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException e) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

		return empList;
	}

	@Override
	public List<employees> getEmployeesByJobId(String jobId) {
		// TODO Auto-generated method stub
		ArrayList<employees> empList = new ArrayList<employees>();
		try {
			Connection conn = getConnection();
			Statement stat = conn.createStatement();
			String q = "SELECT * FROM employees where job_id='" + jobId + "'";
			Log.info(q);

			ResultSet rs = stat.executeQuery(q);
			while (rs.next()) {
				employees e = new employees(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getDouble(9), rs.getInt(10), rs.getInt(11));
				empList.add(e);
			}

		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (Exception e) {
			System.out.println("Error...");
		}
		return empList;
	}

	@Override
	public employees getEmployeeById(int employeeId) throws Exception {
		// TODO Auto-generated method stub
		employees emp = null;
		try {
			Connection conn = getConnection();
			String q = "SELECT * FROM employees where employee_id=?";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setInt(1, employeeId);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				emp = new employees(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getDouble(9), rs.getInt(10), rs.getInt(11));

			}
			Log.info("Data Retrived..");
		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException e) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

		return emp;

	}

	@Override
	public employees getEmployeeByEmail(String email) throws Exception {
		// TODO Auto-generated method stub
		employees emp = null;
		try {
			Connection conn = getConnection();
			String q = "SELECT * FROM employees where email=?";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				emp = new employees(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getDouble(9), rs.getInt(10), rs.getInt(11));

			}
		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException e) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

		return emp;

	}

	@Override
	public void addEmployee(employees e) throws Exception {
		// TODO Auto-generated method stub
		try {
			Connection conn = getConnection();
			String q = "insert into employees values(?,?,?,?,?,?,?,?,?,?,?)";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setInt(1, e.getEmployeeId());
			ps.setString(2, e.getFirstName());
			ps.setString(3, e.getLastName());
			ps.setString(4, e.getEmail());
			ps.setString(5, e.getPhoneNumber());
			ps.setString(6, e.getHireDate());
			ps.setString(7, e.getJobId());
			ps.setDouble(8, e.getSalary());
			ps.setDouble(9, e.getCommissionPct());
			ps.setInt(10, e.getManagerId());
			ps.setInt(11, e.getDepartmentId());

			int i = ps.executeUpdate();
			System.out.println(i);

		} catch (NullPointerException ex) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException ex) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception ex) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

	}

	@Override
	public void updateEmployee(employees e) throws Exception {
		// TODO Auto-generated method stub
		try {
			Connection conn = getConnection();
			String q = "update employees set first_name=? where employee_id=? ";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setString(1, e.getFirstName());
			ps.setInt(2, e.getEmployeeId());
			int i = ps.executeUpdate();
			System.out.println(i);

		} catch (NullPointerException ex) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException ex) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception ex) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

	}

	@Override
	public void deleteEmployee(int employeeId) throws Exception {
		// TODO Auto-generated method stub
		try {
			Connection conn = getConnection();
			String q = "delete employees where employee_id=? ";
			Log.info(q);
			PreparedStatement ps = conn.prepareStatement(q);
			ps.setInt(1, employeeId);
			int i = ps.executeUpdate();
			System.out.println(i);

		} catch (NullPointerException e) {
			System.out.println("Connection Not Established.......");
		} catch (SQLException e) {
			System.out.println("Error in Sql Execution.....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}

	}

}
