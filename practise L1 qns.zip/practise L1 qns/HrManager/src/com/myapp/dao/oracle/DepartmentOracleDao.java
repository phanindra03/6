package com.myapp.dao.oracle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.myapp.dao.departmentsDAO;
import com.myapp.datasource.DataSource;
import com.myapp.entity.departments;

public class DepartmentOracleDao implements departmentsDAO {

	private Connection getConnection() {
		Connection conn = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(
					"C:\\Users\\bmarni\\workspace\\HrManager\\src\\db.properties");
			Properties prop = new Properties();
			prop.load(fis);
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String username = prop.getProperty("user");
			String password = prop.getProperty("password");
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Class Not Found......");
		} catch (FileNotFoundException e) {
			System.out.println("Properties File Not Found.....");
		} catch (SQLException e) {
			System.out.println("Connection Establishment Failed......");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error.....");
		}
		return conn;
	}

	@Override
	public List<departments> getAllDepartments() throws Exception {
		// TODO Auto-generated method stub
		ArrayList<departments> depList = new ArrayList<departments>();

//		Connection conn = getConnection();
		Connection conn=DataSource.getConnection();
		Statement stat = conn.createStatement();
		String q = "select * from departments";
		ResultSet rs = stat.executeQuery(q);
		departments d = null;
		while (rs.next()) {
			d = new departments(rs.getInt(1), rs.getString(2), rs.getInt(3),
					rs.getInt(4));
			depList.add(d);
		}
		return depList;
	}

	@Override
	public departments getDepartmentById(int departmentId) throws Exception {
		// TODO Auto-generated method stub

		Connection conn = DataSource.getConnection();
		Statement stat = conn.createStatement();
		String q = "select * from departments where department_id="
				+ departmentId;
		ResultSet rs = stat.executeQuery(q);
		departments d = null;
		while (rs.next()) {
			d = new departments(rs.getInt(1), rs.getString(2), rs.getInt(3),
					rs.getInt(4));

		}
		return d;

	}

	@Override
	public List<departments> getDepartmentsByLocationId(int locationId)
			throws Exception {
		// TODO Auto-generated method stub
		ArrayList<departments> depList = new ArrayList<departments>();
//		Connection conn = DataSource.getConnection();
		Connection conn=getConnection();
		Statement stat = conn.createStatement();
		String q = "select * from departments where location_id =" + locationId;
		ResultSet rs = stat.executeQuery(q);
		departments d = null;
		while (rs.next()) {
			d = new departments(rs.getInt(1), rs.getString(2), rs.getInt(3),
					rs.getInt(4));
			depList.add(d);
		}
		return depList;

	}

	@Override
	public departments getDepartmentByManagerId(int managerId) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = getConnection();
//		Connection conn=DataSource.getConnection();
		Statement stat = conn.createStatement();
		String q = "select * from departments where department_id=" + managerId;
		ResultSet rs = stat.executeQuery(q);
		departments d = null;
		while (rs.next()) {
			d = new departments(rs.getInt(1), rs.getString(2), rs.getInt(3),
					rs.getInt(4));

		}
		return d;

	}

	@Override
	public void addDepartment(departments d) throws Exception {
		// TODO Auto-generated method stub
		Connection conn=getConnection();
//		Connection conn=DataSource.getConnection();
		String q="insert into departments values(?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(q);
		ps.setInt(1, d.getDepartmentId());
		ps.setString(2, d.getDepartmentName());
		ps.setInt(3, d.getManagerId());
		ps.setInt(4, d.getLocationId());
		int i=ps.executeUpdate();
		System.out.println(i);

	}

	@Override
	public void updateDepartment(departments d) throws Exception {
		// TODO Auto-generated method stub
		Connection conn=getConnection();
//		Connection conn=DataSource.getConnection();
		String q="update departments set manager_id=? where department_id=?";
		PreparedStatement ps=conn.prepareStatement(q);
		ps.setInt(1, d.getManagerId());
		ps.setInt(2, d.getDepartmentId());
		int i=ps.executeUpdate();
		System.out.println(i);

	}

	@Override
	public void deleteDepartmentById(int departmentId) throws Exception {
		// TODO Auto-generated method stub
		Connection conn=getConnection();
//		Connection conn=DataSource.getConnection();
		String q ="delete departments where department_id=?";
		PreparedStatement ps=conn.prepareStatement(q);
		ps.setInt(1, departmentId);
		int i=ps.executeUpdate();
		System.out.println(i);

	}

}
