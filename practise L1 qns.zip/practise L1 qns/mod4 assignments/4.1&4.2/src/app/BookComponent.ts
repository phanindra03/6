import { Component, OnInit } from '@angular/core';
import {Book} from "./Book";
import {BookListService} from './BookListService';
import {Http} from '@angular/http';

@Component({
selector:'app-BookComponent',
templateUrl:'./BookComponent.html',
providers:[BookListService]

})

export class BookComponent implements OnInit{
books:Book[];
constructor(private booklistservice:BookListService) { }

ngOnInit(){
this.booklistservice.getJSON().subscribe((booksData)=>this.books=booksData);
}
deleteData(obj:Book)
{
var index=this.books.indexOf(obj);
this.books.splice(index,1);
}
boo:Book[]=[];
id:number;
title:string;
year:number;
author:string;
addData():void
{
if(this.id!=null&&this.title!=null&&this.year!=null&&this.author!=null)
{
let book:Book={id:this.id,title:this.title,year:this.year,author:this.author};
this.books.push(book);
alert("insert data");
}
else{
alert("insert data");
}
}
sortById(): void 
  {
    this. books.sort((a,b)=>a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
  
  sortByTitle(): void 
  {
    this. books.sort((a,b)=>a.title < b.title ? -1 : a.title > b.title ? 1 : 0);
  }
  
   sortByYear(): void 
  {
    this. books.sort((a,b)=>a.year < b.year ? -1 : a.year > b.year ? 1 : 0);
  }
  
   sortByAuthor(): void 
  {
    this. books.sort((a,b)=>a.author < b.author ? -1 : a.author > b.author ? 1 : 0);
  }
}
