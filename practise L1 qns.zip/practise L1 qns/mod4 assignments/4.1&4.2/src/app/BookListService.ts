import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import { Http,Response } from "@angular/http"
import 'rxjs/add/operator/map';
import {Book} from "./Book";
import 'rxjs/add/operator/catch';

@Injectable()
export class BookListService{

constructor(private http:Http){}

public getJSON():Observable<Book[]>{
return this.http.get('/app/booklist.json').map((response:Response)=><Book[]>response.json());
}
}
