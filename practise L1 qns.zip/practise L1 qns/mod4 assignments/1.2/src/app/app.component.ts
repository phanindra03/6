import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<my-component></my-component>`,
})
export class AppComponent  { name = 'Angular'; }
