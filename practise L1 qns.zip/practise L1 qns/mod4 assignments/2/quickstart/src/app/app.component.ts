import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template :'<app-EmployeeComponent></app-EmployeeComponent>',
})
  

export class AppComponent  { }
