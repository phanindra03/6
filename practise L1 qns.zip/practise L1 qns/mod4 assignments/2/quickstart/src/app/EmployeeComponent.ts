import {Component,OnInit} from '@angular/core';

import {EmployeeServiceList} from './EmployeeServiceList';
import {Http} from '@angular/http';
import {Employee} from "./Employee";

@Component({
	selector:'app-EmployeeComponent',
	templateUrl:'./EmployeeComponent.html',
	
})

export class EmployeeComponent implements OnInit{
id:number;
name:string;
salary:number;
department:string;
employees:Employee[];
constructor(private employeelistservice:EmployeeServiceList){}
ngOnInit(){
this.employeelistservice.getJSON().subscribe((employeesData=>this.employees=employeesData));
}

delete(obj:Employee)
{
var index=this.employees.indexOf(obj);
this.employees.splice(index,1);
}
addData():void
{
if(this.id!=null&&this.name!=null&&this.salary!=null&&this.department!=null)
{
let b:Employee={id:this.id,name:this.name,salary:this.salary,department:this.department};
this.employees.push(b);

}
else{
alert("insert data")
}
}
} 
  
 




