import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Employee} from "./Employee";
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class EmployeeServiceList{
employee:Employee[];
constructor(private http:Http){ }
	public getJSON():Observable<Employee[]>
	{
	return this.http.get('/app/employeelist.json').map((response:Response)=><Employee[]>response.json());
	}

}
