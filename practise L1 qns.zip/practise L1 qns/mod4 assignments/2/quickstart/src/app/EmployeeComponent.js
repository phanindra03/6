"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var EmployeeServiceList_1 = require("./EmployeeServiceList");
var EmployeeComponent = (function () {
    function EmployeeComponent(employeelistservice) {
        this.employeelistservice = employeelistservice;
    }
    EmployeeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.employeelistservice.getJSON().subscribe((function (employeesData) { return _this.employees = employeesData; }));
    };
    EmployeeComponent.prototype.delete = function (obj) {
        var index = this.employees.indexOf(obj);
        this.employees.splice(index, 1);
    };
    EmployeeComponent.prototype.addData = function () {
        if (this.id != null && this.name != null && this.salary != null && this.department != null) {
            var b = { id: this.id, name: this.name, salary: this.salary, department: this.department };
            this.employees.push(b);
        }
        else {
            alert("insert data");
        }
    };
    return EmployeeComponent;
}());
EmployeeComponent = __decorate([
    core_1.Component({
        selector: 'app-EmployeeComponent',
        templateUrl: './EmployeeComponent.html',
    }),
    __metadata("design:paramtypes", [EmployeeServiceList_1.EmployeeServiceList])
], EmployeeComponent);
exports.EmployeeComponent = EmployeeComponent;
//# sourceMappingURL=EmployeeComponent.js.map