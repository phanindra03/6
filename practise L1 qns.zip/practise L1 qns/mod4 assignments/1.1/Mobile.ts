export class Mobile{
mobileId:number;
mobileName:string;
mobileCost:number;
mobileType:string;
	
}


