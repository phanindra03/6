import {Mobile} from "./Mobile";
export class BasicPhone extends Mobile{
mobileType:string="BasicPhone";

}