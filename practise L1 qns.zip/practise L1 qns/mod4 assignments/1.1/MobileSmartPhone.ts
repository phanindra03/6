import {Mobile} from "./Mobile";
export class SmartPhone extends Mobile {

mobileType:string="SmartPhone";
}