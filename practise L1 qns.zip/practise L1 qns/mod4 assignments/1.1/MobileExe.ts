import {Mobile} from "./Mobile";
import {BasicPhone} from "./MobileBasicPhone";
import {SmartPhone} from "./MobileSmartPhone";

let bp:BasicPhone= new BasicPhone();
let sp:SmartPhone= new SmartPhone();
let mobArr:Mobile[]=[

	{mobileId:101,mobileName:"OnePlus",mobileCost:30000,mobileType:sp.mobileType},
	{mobileId:102,mobileName:"Pixel",mobileCost:40000,mobileType:sp.mobileType},
	{mobileId:103,mobileName:"IPhone",mobileCost:50000,mobileType:bp.mobileType}
	];
	
mobArr.push({
mobileId:104,mobileName:"Samsung",mobileCost:5000,mobileType:bp.mobileType
});
for(let m of mobArr){	
console.log("Mobile Id is :"+m.mobileId);
console.log("Mobile Name is: "+m.mobileName);
console.log("Mobile Type is: "+m.mobileType);
console.log("********************");
}
