package com.capgemini.MobilePurchaseSystem.dao;

import java.util.ArrayList;

import com.capgemini.MobilePurchaseSystem.beans.MobilePurchaseCustomerbeans;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseException;

public interface IMobilePurchaseDao {

	
	public MobilePurchaseCustomerbeans mobilePurchaseSystem(MobilePurchaseCustomerbeans mps)throws MobilePurchaseException;
	public ArrayList<MobilePurchaseCustomerbeans> getAllMobiles()
			throws MobilePurchaseException;
	public ArrayList<MobilePurchaseCustomerbeans> getSearchedMobiles(int min, int max);
}


