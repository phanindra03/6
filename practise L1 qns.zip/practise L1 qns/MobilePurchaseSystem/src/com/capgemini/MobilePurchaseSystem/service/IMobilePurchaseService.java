package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.MobilePurchaseSystem.beans.MobilePurchaseCustomerbeans;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseException;

public interface IMobilePurchaseService {
	
	public MobilePurchaseCustomerbeans mobilePurchaseSystem(MobilePurchaseCustomerbeans cusdto) throws MobilePurchaseException;
	
	 boolean ValidateCustomerName(String custerName);
	 boolean ValidateMailId(String mailId);
	 boolean ValidatePhoneNumber(String phoneNum);
	 boolean ValidateMobileId(long mobileId);
	 boolean ValidatePurchaseId(String purchaseId);
	//abstract boolean ValidatePurchaseDate();
	 public int getPID() throws MobilePurchaseException, SQLException;
	 public ArrayList<Long> getMobileId() throws SQLException, MobilePurchaseException;
	 public ArrayList<MobilePurchaseCustomerbeans> getAllMobiles()throws MobilePurchaseException;
	 public ArrayList<MobilePurchaseCustomerbeans> getSearchedMobiles(int min, int max);
	 public void delRecord(int del) throws MobilePurchaseException;
		 
}
